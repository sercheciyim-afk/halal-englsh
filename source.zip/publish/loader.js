(() => {
 const overlay=document.getElementById('arrival'),canvas=document.getElementById('letter-light'),ctx=canvas.getContext('2d');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 let width=0,height=0,frame=0,stopped=false;
 const letters='Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz'.split(' ');
 const points=letters.map((letter,i)=>({letter,x:.1+((i*37)%89)/110,y:.08+((i*23)%67)/112,size:24+(i*13)%30,rotate:((i*7)%17-8)*Math.PI/180}));
 function resize(){width=innerWidth;height=innerHeight;const scale=Math.min(devicePixelRatio||1,2);canvas.width=width*scale;canvas.height=height*scale;ctx.setTransform(scale,0,0,scale,0,0);if(reduced)draw(2600);}
 function glyphs(color){ctx.fillStyle=color;for(const p of points){ctx.save();ctx.translate(p.x*width,p.y*height);ctx.rotate(p.rotate);ctx.font=`${p.size*(width<500?.85:1.15)}px Georgia`;ctx.fillText(p.letter,0,0);ctx.restore();}}
 function draw(t){
  if(!ctx||stopped)return;
  ctx.clearRect(0,0,width,height);
  glyphs('#25291f');
  const x=width*.5,y=height*.57,angle=-Math.PI/2+Math.sin(t/2400)*1.03,r=Math.max(width,height),spread=.32;
  ctx.save();ctx.beginPath();ctx.moveTo(x,y);ctx.arc(x,y,r,angle-spread,angle+spread);ctx.closePath();ctx.clip();
  const beam=ctx.createRadialGradient(x,y,0,x,y,r*.85);beam.addColorStop(0,'#e8bf732b');beam.addColorStop(.35,'#b8a66e20');beam.addColorStop(1,'#b8a66e00');ctx.fillStyle=beam;ctx.fillRect(0,0,width,height);
  ctx.shadowColor='#b8a66e';ctx.shadowBlur=12;glyphs('#c3b27c');ctx.restore();
  ctx.save();ctx.translate(x,y+12);
  const glow=ctx.createRadialGradient(0,0,0,0,0,90);glow.addColorStop(0,'#edbd613d');glow.addColorStop(.45,'#d2913320');glow.addColorStop(1,'#d2913300');ctx.fillStyle=glow;ctx.fillRect(-90,-90,180,180);
  const brass=ctx.createLinearGradient(-26,0,26,0);brass.addColorStop(0,'#46321b');brass.addColorStop(.3,'#ac8750');brass.addColorStop(.5,'#6a4a27');brass.addColorStop(.76,'#c09a59');brass.addColorStop(1,'#3b2917');
  ctx.strokeStyle=brass;ctx.lineWidth=3;
  ctx.beginPath();ctx.moveTo(-14,-35);ctx.bezierCurveTo(-38,-88,38,-88,14,-35);ctx.stroke();
  ctx.fillStyle=brass;ctx.beginPath();ctx.moveTo(-22,-30);ctx.lineTo(-13,-42);ctx.lineTo(13,-42);ctx.lineTo(22,-30);ctx.closePath();ctx.fill();
  ctx.fillRect(-24,-30,48,5);ctx.fillRect(-26,40,52,6);
  ctx.beginPath();ctx.moveTo(-26,46);ctx.lineTo(-20,52);ctx.lineTo(20,52);ctx.lineTo(26,46);ctx.closePath();ctx.fill();
  const glass=ctx.createLinearGradient(-18,0,18,0);glass.addColorStop(0,'#81501a66');glass.addColorStop(.45,'#fbdc9f99');glass.addColorStop(1,'#81501a66');ctx.fillStyle=glass;
  ctx.beginPath();ctx.moveTo(-15,-23);ctx.bezierCurveTo(-15,-2,-23,17,-17,35);ctx.lineTo(17,35);ctx.bezierCurveTo(23,17,15,-2,15,-23);ctx.closePath();ctx.fill();
  ctx.strokeStyle=brass;ctx.lineWidth=4;for(const side of [-1,1]){ctx.beginPath();ctx.moveTo(side*20,-26);ctx.bezierCurveTo(side*24,-4,side*27,22,side*23,40);ctx.stroke();}
  ctx.fillStyle='#ffe3a3';ctx.shadowColor='#ffce6b';ctx.shadowBlur=20;ctx.beginPath();ctx.moveTo(0,5);ctx.bezierCurveTo(-2,16,-9,22,-4,28);ctx.bezierCurveTo(7,35,9,19,0,5);ctx.fill();ctx.shadowBlur=0;
  ctx.fillStyle=brass;ctx.fillRect(-9,30,18,5);ctx.lineWidth=1;ctx.strokeStyle='#f4d7a54d';ctx.beginPath();ctx.moveTo(-10,-18);ctx.lineTo(-14,17);ctx.stroke();ctx.restore();
  if(!reduced)frame=requestAnimationFrame(draw);
 }
 addEventListener('resize',resize);resize();if(!reduced)frame=requestAnimationFrame(draw);
 window.finishArrival=()=>{stopped=true;cancelAnimationFrame(frame);removeEventListener('resize',resize);overlay.classList.add('leaving');setTimeout(()=>overlay.remove(),reduced?0:700);};
 let finished=0;
 const imageNames=['door','room','book','ticket','letter','avatar'];
 function progress(){finished++;}
 const images=imageNames.map(name=>new Promise(resolve=>{const img=new Image();img.onload=()=>{(img.decode?img.decode():Promise.resolve()).catch(()=>{}).finally(()=>{progress();resolve(true);});};img.onerror=()=>{progress();resolve(false);};img.src='./'+name+'.webp';}));
 const fonts=[['Cormorant Garamond',400],['Cormorant Garamond',500],['Golos Text',400],['Golos Text',500]].map(([name,weight])=>document.fonts.load(`${weight} 16px "${name}"`).catch(()=>{}).then(progress));
 window.halalAssetsReady=Promise.race([Promise.all([...images,...fonts]),new Promise(resolve=>setTimeout(resolve,15000))]);
 setTimeout(()=>{if(document.getElementById('arrival')&&!window.halalAppMounted){const retry=document.createElement('button');retry.className='arrival-error';retry.textContent='Повторить загрузку';retry.onclick=()=>location.reload();overlay.append(retry);}},20000);
})();
