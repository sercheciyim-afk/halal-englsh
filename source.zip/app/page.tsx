'use client';
import { useEffect, useRef, useState } from 'react';
type Scene = 'door' | 'room' | 'book' | 'ticket' | 'letter';
const quotes = [
  {en:'A good word is also charity.', ru:'Доброе слово тоже милостыня.', context:'В хадисе о ежедневной милостыне названы также справедливость, помощь путнику, шаги к молитве и устранение помех с дороги. Добро не ограничивается деньгами.', source:'Сахих аль-Бухари, 2989', url:'https://sunnah.com/bukhari:2989', excerpt:true},
  {en:'Make things easy and do not make them difficult. Give glad tidings and do not drive people away.', ru:'Облегчайте и не усложняйте. Радуйте доброй вестью и не отталкивайте людей.', context:'Наставление Пророка ﷺ передал Анас ибн Малик. В сборнике оно приведено в книге о знании, в главе о бережном наставлении людей.', source:'Сахих аль-Бухари, 69', url:'https://sunnah.com/bukhari:69', excerpt:false},
  {en:'None of you truly believes until he loves for his brother what he loves for himself.', ru:'Никто из вас не уверует по-настоящему, пока не пожелает своему брату того же, чего желает себе.', context:'Передал Анас ибн Малик. Хадис связывает веру с искренним пожеланием добра брату по вере.', source:'Сахих аль-Бухари, 13', url:'https://sunnah.com/bukhari:13', excerpt:false},
  {en:'Whoever believes in Allah and the Last Day should speak good or remain silent.', ru:'Пусть тот, кто верует в Аллаха и Последний день, говорит благое или молчит.', context:'Это часть хадиса, переданного Абу Хурайрой: в нём также велено не причинять вреда соседу и щедро принимать гостя.', source:'Сахих аль-Бухари, 6018', url:'https://sunnah.com/bukhari:6018', excerpt:true},
  {en:'Gentleness beautifies whatever it is in, and its absence makes things flawed.', ru:'Мягкость украшает всё, в чём она есть, а её отсутствие делает это несовершенным.', context:'Полное короткое наставление, переданное Аишей, супругой Пророка ﷺ. В «Сахих Муслим» оно приведено в главе о достоинстве мягкости.', source:'Сахих Муслим, 2594a', url:'https://sunnah.com/muslim:2594a', excerpt:false},
  {en:'Allah helps His servant as long as the servant helps his brother.', ru:'Аллах помогает Своему рабу, пока тот помогает своему брату.', context:'В этом хадисе Абу Хурайры также говорится об облегчении чужой нужды, сокрытии недостатков, поиске знания и совместном изучении Корана.', source:'Сахих Муслим, 2699a', url:'https://sunnah.com/muslim:2699a', excerpt:true}
];
const questions = [
 {title:'Найти свой выход',prompt:'Ты едешь на умру и ищешь выход на посадку. Как спросишь дорогу?', options:['Excuse me, where is gate B12?','What time does boarding start?','How much is this ticket?'],correct:0,explanation:'«Извините, где выход B12?» Where помогает спросить о месте. Вариант B — о времени посадки, C — о цене.',skill:'travel'},
 {title:'Представиться',prompt:'Выбери фразу: «Я из России».',options:['I be from Russia.','I am from Russia.','I is from Russia.'],correct:1,explanation:'I am from Russia — «Я из России». С I используется форма am.',skill:'basics'},
 {title:'В аэропорту',prompt:'На табло написано: “Boarding starts at 14:30.” Что это значит?',options:['Самолёт прилетает в 14:30.','Выход закроется в 14:30.','Посадка начинается в 14:30.'],correct:2,explanation:'Boarding — посадка на самолёт, starts — начинается.',skill:'travel'},
 {title:'В отеле',prompt:'Как вежливо попросить повторить сказанное?',options:['Could you repeat that, please?','Could you book a room, please?','Could you open the door, please?'],correct:0,explanation:'«Не могли бы вы повторить, пожалуйста?» Repeat означает «повторить».',skill:'travel'},
 {title:'О вчерашнем дне',prompt:'Выбери слово: “Yesterday, we ___ in Jeddah.”',options:['arrive','arrived','arriving'],correct:1,explanation:'Yesterday — «вчера». Для завершённого события нужен Past Simple: arrived.',skill:'basics'},
 {title:'Читаем со смыслом',prompt:'“She kept reading although she was tired.” Как точнее передать смысл?',options:['Она читала, потому что устала.','Она перестала читать, когда устала.','Она продолжала читать, хотя устала.'],correct:2,explanation:'Although — «хотя», а kept reading — «продолжала читать».',skill:'reading'},
 {title:'План на поездку',prompt:'Выбери продолжение: “If I miss the bus, I ___ a taxi.”',options:['will take','took','would have taken'],correct:0,explanation:'Реальная возможность в будущем: If + Present Simple, затем will + глагол.',skill:'basics'},
 {title:'Между строк',prompt:'“The museum was closed, so we visited the library instead.” Почему они пошли в библиотеку?',options:['Она была рядом с музеем.','Музей был закрыт, и они изменили план.','Они заранее собирались только в библиотеку.'],correct:1,explanation:'So показывает следствие, instead — замену: библиотека стала альтернативой закрытому музею.',skill:'reading'}
];
function getResult(score:number){
 if(score<=2) return {level:'Начало пути · до A1',text:'Начни с базовых конструкций: I am, простых вопросов и самых нужных слов. Затем добавь фразы для аэропорта и отеля и короткие тексты с переводом.'};
 if(score<=4) return {level:'Первые опоры · A1',text:'У тебя уже есть знакомые слова и фразы. Укрепи базовую грамматику, потренируй вопросы и понимание ответов. Для поездок добавь бытовые диалоги, для чтения — короткие адаптированные тексты.'};
 if(score<=6) return {level:'База растёт · A1–A2',text:'Ты понимаешь многие повседневные фразы. Следующий шаг — прошедшее и будущее время, связки между предложениями и диалоги в поездках. Читай небольшие тексты и пересказывай их своими словами.'};
 return {level:'Уверенная база · A2, шаг к B1',text:'Ты хорошо справилась с фразами и текстами этого квиза. Продолжай развивать понимание на слух и разговорную практику, читай более длинные тексты и объясняй их смысл по-английски.'};
}
export default function Home() {
  const [scene, setScene] = useState<Scene>('door');
  const [page, setPage] = useState(0);
  const [book, setBook] = useState(false);
  const [ticket, setTicket] = useState(false);
  const [quizIndex,setQuizIndex] = useState(0);
  const [attempts,setAttempts] = useState<number[]>([]);
  const [selected,setSelected] = useState<number|null>(null);
  const [quizDone,setQuizDone] = useState(false);
  const [letterPage,setLetterPage] = useState(0);
  const [progressLoaded,setProgressLoaded] = useState(false);
  const [hint, setHint] = useState('');
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { try {
    const p = JSON.parse(localStorage.getItem('halal-story-progress-v2') || '{}');
    if (typeof p.book === 'boolean') setBook(p.book);
    if (Array.isArray(p.attempts) && p.attempts.length<=questions.length && p.attempts.every((x:number)=>Number.isInteger(x)&&x>=-1&&x<=2)) {
      setAttempts(p.attempts);
      const done=p.attempts.length===questions.length && p.done===true;
      setQuizDone(done);setTicket(p.ticket===true || done);
      setQuizIndex(Math.min(p.index || 0,questions.length-1));
      setSelected(p.selected ?? null);
    }
  } catch {} setProgressLoaded(true); }, []);
  useEffect(()=>{if(progressLoaded) try {localStorage.setItem('halal-story-progress-v2',JSON.stringify({book,ticket,attempts,index:quizIndex,selected,done:quizDone}));}catch{}},[book,ticket,attempts,quizIndex,selected,quizDone,progressLoaded]);
  const save = (b:boolean,t:boolean) => {setBook(b);setTicket(t);};
  const question=questions[quizIndex];
  const score=attempts.reduce((total,choice,i)=>total+(choice===questions[i].correct?1:0),0);
  const result=getResult(score);
  const choose=(choice:number)=>{if(selected===question.correct)return;setSelected(choice);setAttempts(old=>old.length>quizIndex?old:[...old,choice]);};
  const advanceQuiz=(skip=false)=>{
    if(skip && attempts.length===quizIndex)setAttempts(old=>[...old,-1]);
    if(quizIndex===questions.length-1){setQuizDone(true);setTicket(true);}
    else {setQuizIndex(i=>i+1);setSelected(null);}
  };
  const restartQuiz=()=>{setQuizIndex(0);setAttempts([]);setSelected(null);setQuizDone(false);};
  const go = (next: Scene) => { if(next==='letter')setLetterPage(0); setHint(''); setScene(next); window.scrollTo(0,0); };
  useEffect(() => { heading.current?.focus({preventScroll:true}); }, [scene]);
  useEffect(() => { const onKey = (e: KeyboardEvent) => { if(e.key === 'Escape' && scene !== 'door' && scene !== 'room') go('room'); }; window.addEventListener('keydown',onKey); return () => window.removeEventListener('keydown',onKey); }, [scene]);
  const ready = book && ticket;
  const back = <button className="margin-link back" onClick={() => go('room')}>← Вернуться в комнату</button>;
  const title = {door:'Halal English',room:'Вечер в кабинете',book:'Страницы со смыслом',ticket:'Маленькое путешествие',letter:'Письмо для тебя'}[scene];
  return <main className={`story ${scene}-scene`}>
    <h1 className="sr-only" tabIndex={-1} ref={heading}>{title}</h1>
    <div className="ambient" style={{backgroundImage:`url(/images/${scene === 'door' ? 'door' : scene === 'room' ? 'room' : 'book'}.jpg)`}} aria-hidden="true" />
    {scene === 'door' && <div className="stage door-stage">
      <img className="scene-image" src="/images/door.jpg" alt="Резная деревянная дверь с гравировкой Halal English на латунной табличке" fetchPriority="high" />
      <button className="door-hit" aria-label="Открыть дверь и войти в кабинет" onClick={() => go('room')} />
      <p className="door-note">Нажми на дверь, чтобы войти<span>Небольшая история о твоём английском</span></p>
    </div>}
    {scene === 'room' && <div className="room-wrap">
      <div className="stage room-stage">
        <img className="scene-image" src="/images/room.jpg" alt="Вечерний кабинет. Книга на левой полке, билет на тумбочке у зеркала, запечатанное письмо на письменном столе." />
        <div className="room-intro"><span className="eyebrow">HALAL ENGLISH</span><p>У каждой вещи — своя история.</p><small>Коснись книги, билета или письма</small></div>
        <button className="hotspot book-hit" aria-label={book?'Рассмотреть книгу ещё раз':'Рассмотреть книгу'} onClick={() => {setPage(0); go('book');}}><span className="hotspot-caption">Книга{book?' · прочитана':''}</span></button>
        <button className="hotspot ticket-hit" aria-label={ticket?'Рассмотреть билет ещё раз':'Рассмотреть билет'} onClick={() => go('ticket')}><span className="hotspot-caption">Билет{ticket?' · пройден':''}</span></button>
        <button className={`hotspot letter-hit ${ready?'unsealed':''}`} aria-label={ready?'Открыть письмо':'Запечатанное письмо'} onClick={() => ready?go('letter'):setHint('Сначала рассмотри книгу и билет')}><span className="hotspot-caption">{ready?'Письмо для тебя':'Письмо запечатано'}</span></button>
        <p className="room-status" role="status">{hint || (ready?'Теперь можно открыть письмо.':book?'Книга прочитана. Тебя ждёт билет.':ticket?'Билет пройден. Загляни в книгу.':'Начни с книги или билета.')}</p>
        <button className="margin-link entrance" onClick={() => go('door')}>К двери</button>
      </div>
    </div>}
    {scene === 'book' && <div className="reading-wrap">{back}<div className="stage book-stage">
      <img className="scene-image" src="/images/book.jpg" alt="Раскрытая книга с кремовой бумагой на деревянном столе" />
      <article className="book-copy" key={page}>
        <span className="eyebrow">СЛОВА, В КОТОРЫХ ЕСТЬ СМЫСЛ</span>
        <div className="quote"><span className="quote-kind">{quotes[page].excerpt?'Отрывок · перевод смысла':'Перевод смысла хадиса'}</span><p className="english" lang="en">{quotes[page].en}</p><p className="translation">{quotes[page].ru}</p><p className="quote-context">{quotes[page].context}</p><a className="source" href={quotes[page].url} target="_blank" rel="noopener noreferrer">{quotes[page].source} ↗</a></div>
        <div className="book-bottom"><span className="folio">0{page+1} / 06</span>{page < quotes.length-1?<button className="ink-link" onClick={() => {setPage(p=>p+1);if(page===quotes.length-2)save(true,ticket);}}>Перелистнуть →</button>:<button className="ink-link" onClick={() => go('room')}>Вернуться в комнату →</button>}</div>
        <button className="previous-page" disabled={page===0} onClick={() => setPage(p=>p-1)}>← Предыдущая страница</button>
      </article>
    </div></div>}
    {scene === 'ticket' && <div className="reading-wrap">{back}<div className="stage ticket-stage">
      <img className="scene-image" src="/images/ticket.jpg" alt="Старинный бумажный посадочный талон на тумбочке у зеркала" />
      <article className="ticket-copy">
        <header className="ticket-header"><span className="eyebrow">BOARDING PASS · UMRAH</span><div><h2 lang="en">JEDDAH</h2><span lang="en">GATE<br/><strong>B12</strong></span></div></header>
        <div className="ticket-main quiz-main">{!quizDone?<>
          <span className="eyebrow">ВОПРОС {quizIndex+1} / {questions.length}</span><h3>{question.title}</h3>
          <p>{question.prompt}</p>
          <div className="answers" aria-label="Варианты ответа">{question.options.map((option,i)=><button key={i} className={`answer ${selected===i?(i===question.correct?'correct':'incorrect'):''}`} aria-pressed={selected===i} disabled={selected===question.correct} onClick={()=>choose(i)}><span className="answer-letter">{String.fromCharCode(65+i)}.</span><span>{option}</span><span className="ink-check" aria-hidden="true">{selected===i && i===question.correct?'✓':''}</span></button>)}</div>
          <div className="answer-feedback" aria-live="polite">{selected===question.correct?<><span className="eyebrow">ВЕРНО</span><p>{question.explanation}</p></>:selected!==null?<><p>Попробуй ещё раз.</p><small>Этот вариант не подходит по смыслу или грамматике. Для результата уже учтён первый ответ.</small></>:<small>Для результата учитывается первая попытка. Можно исправлять ошибки или пропустить вопрос.</small>}</div>
          <div className="quiz-actions">{selected===question.correct?<button className="ink-link" onClick={()=>advanceQuiz()}>{quizIndex===questions.length-1?'Узнать результат':'Следующий вопрос'} →</button>:<button className="ink-link" onClick={()=>advanceQuiz(true)}>Не знаю · дальше →</button>}</div>
          <button className="ink-link ticket-return" onClick={()=>go('room')}>Вернуться в комнату →</button>
        </>:<div className="quiz-result" aria-live="polite"><span className="eyebrow">ТВОЙ РЕЗУЛЬТАТ · {score} / {questions.length}</span><h3>Твой следующий шаг</h3><p className="level">{result.level}</p><p>{result.text}</p><small className="result-note">Это ориентир по 8 вопросам на лексику, грамматику и чтение, а не полноценное определение уровня. Разговор и понимание на слух здесь не проверялись.</small><p className="result-invite">{book?'Отлично! Вернись в комнату и нажми на письмо — там для тебя кое-какое послание и приглашение продолжить.':'Отлично! Вернись в комнату, дочитай книгу и нажми на письмо — там для тебя кое-какое послание и приглашение продолжить.'}</p><button className="ink-link ticket-return" onClick={()=>go('room')}>Вернуться в комнату →</button><button className="previous-page" onClick={restartQuiz}>Пройти квиз ещё раз</button></div>}</div>
      </article>
    </div></div>}
    {scene === 'letter' && <div className="letter-wrap"><nav className="letter-nav">{back}<span>HALAL ENGLISH</span></nav>
      <article className="letter-sheet paged-letter" aria-label={`Письмо, страница ${letterPage+1} из 9`}><div className="letter-copy">
        <div className="letter-body" key={letterPage}>
        {letterPage===0 && <><span className="eyebrow">ЛИЧНОЕ ПИСЬМО</span><h2>Ассаляму алейкум!</h2><p>Может быть, у тебя уже есть книга, которую ты хочешь прочитать в оригинале. Или тебе хочется в следующей поездке самой спросить дорогу и понять ответ. Ты уже попробовала и то и другое в этой комнате.</p><p className="handwritten">Первые шаги уже сделаны.</p></>}
        {letterPage===1 && <><span className="eyebrow">МАЛЕНЬКИМИ ШАГАМИ</span><h2>Продолжим?</h2><p>Если хочется продолжить, в <span lang="en">Halal English</span> можно начать с простых фраз и постепенно добавлять то, что нужно именно тебе. Даже пятнадцать минут в день — хороший способ начать.</p><p className="handwritten">Маленькими шагами.<br/>В своём ритме. Со смыслом.</p></>}
        {letterPage===2 && <><span className="eyebrow">О ТВОЁМ ОБУЧЕНИИ</span><h2>Три месяца,<br/>чтобы начать говорить</h2><p>Мы пройдём этот путь за <strong>3 месяца</strong>. Внутри — <strong>60 видеоуроков</strong>: три блока, по 20 уроков в каждом.</p><section className="program"><h3 lang="en">Basic English</h3><p>Твоя основа с нуля: шаг за шагом разберём грамматику, лексику и простые фразы, которые пригодятся каждый день.</p></section></>}
        {letterPage===3 && <><span className="eyebrow">ТО, ЧТО БЛИЗКО ТЕБЕ</span><section className="program"><h3 lang="en">Travel English</h3><p>Английский для поездок: спросить дорогу, решить бытовой вопрос и понять собеседника. Чтобы в путешествии чувствовать себя увереннее.</p></section><section className="program"><h3 lang="en">Muslim English</h3><p>Повседневная жизнь, Рамадан, пятница, умра, хадж и биография Пророка.</p></section><p>К урокам идут задания, тесты, подкасты и дополнительные материалы — чтобы новое постепенно становилось привычным.</p></>}
        {letterPage===4 && <><span className="eyebrow">ВЫБЕРИ СВОЙ РИТМ · ТАРИФ 01</span><section className="tariff"><div className="tariff-title"><h3>Самостоятельный</h3><span>23 900 ₽</span></div><p>Для тех, кто хочет пройти курс в своём темпе и получить крепкую базу без сопровождения.</p><ul><li>3 месяца обучения</li><li>Доступ ко всем материалам курса</li><li>Доступ к урокам навсегда</li></ul></section><p className="handwritten">Когда хочется двигаться<br/>в своём темпе.</p></>}
        {letterPage===5 && <><span className="eyebrow">ВЫБЕРИ СВОЙ РИТМ · ТАРИФ 02</span><section className="tariff"><div className="tariff-title"><h3>С куратором</h3><span>29 900 ₽</span></div><p>Если тебе важны поддержка, дисциплина и сопровождение в процессе.</p><ul><li>Всё из тарифа «Самостоятельный»</li><li>Обратная связь от куратора</li><li>Проверка домашних заданий</li><li>Контроль успеваемости и журнал прогресса</li></ul></section><p className="page-aside">Ещё о поддержке — на следующей странице.</p></>}
        {letterPage===6 && <><span className="eyebrow">С КУРАТОРОМ · ПРОДОЛЖЕНИЕ</span><h2>Рядом на этом пути</h2><p>В тариф «С куратором» также входят:</p><section className="tariff"><ul><li>2 созвона с Мадиной</li><li>Доступ в клуб Halal English навсегда</li><li>Участие в системе мотивации и подарков</li></ul></section><p>Всё это входит в стоимость <strong>29 900 ₽</strong>.</p></>}
        {letterPage===7 && <><span className="eyebrow">ВЫБЕРИ СВОЙ РИТМ · ТАРИФ 03</span><section className="tariff"><div className="tariff-title"><h3>Премиум</h3><span>45 900 ₽</span></div><p>Для тех, кто хочет максимум включённости и внимания внутри курса.</p><ul><li>Всё из тарифа «С куратором»</li><li>Усиленное сопровождение в процессе обучения</li><li>Гайд-методичка паломника для комфортного совершения хаджа или умры</li><li>12 тематических эфиров с Мадиной</li></ul></section></>}
        {letterPage===8 && <><span className="eyebrow">ТВОЙ СЛЕДУЮЩИЙ ШАГ</span><h2>Буду рада тебе</h2><p className="installment">Для всех тарифов доступна halal-рассрочка. Об условиях можно спросить менеджера.</p><p>Если чувствуешь, что сейчас твоё время начать, напиши нам. Поможем выбрать подходящий формат.</p><p className="signature">С теплом,<br/><span lang="en">Madina Ayub</span></p><div className="enrollment"><a className="ink-stamp" href="https://wa.me/79882602875" target="_blank" rel="noopener noreferrer">Написать менеджеру<br/>и записаться <span aria-hidden="true">↗</span></a><small>Откроется чат в WhatsApp</small></div></>}
        </div>
        <nav className="letter-pagination" aria-label="Страницы письма"><button className="ink-link" disabled={letterPage===0} onClick={()=>setLetterPage(p=>p-1)}>← Назад</button><span className="folio" aria-live="polite">0{letterPage+1} / 09</span>{letterPage<8?<button className="ink-link" onClick={()=>setLetterPage(p=>p+1)}>Перелистнуть →</button>:<button className="ink-link" onClick={()=>go('room')}>В комнату →</button>}</nav>
      </div></article>
      <footer className="creator-footer"><a href="https://t.me/+zOhyJcE8g_I2NDI8" target="_blank" rel="noopener noreferrer" aria-label="Сайт разработан Amatullah — перейти в Telegram"><img src="/images/avatar.jpg" alt="Аватарка Amatullah"/><span><small>Сайт разработан</small><span>Amatullah <span aria-hidden="true">↗</span></span></span></a></footer>
    </div>}
  </main>;
}
